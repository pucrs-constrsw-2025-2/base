# Upgrade Progress

  ### ✅ Generate Upgrade Plan [View Log](logs\1.generatePlan.log)

  ### ✅ Confirm Upgrade Plan [View Log](logs\2.confirmPlan.log)

  ### ✅ Setup Development Environment [View Log](logs\3.setupEnvironment.log)

  ### ✅ PreCheck [View Log](logs\4.precheck.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  - ###
    ### ✅ Precheck - Build project [View Log](logs\4.1.precheck-buildProject.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    `mvn clean test-compile -q -B -fn`
    </details>
  
    ### ✅ Precheck - Validate CVEs [View Log](logs\4.2.precheck-validateCves.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### CVE issues
    - Dependency `org.apache.commons:commons-lang3` has **1** known CVEs:
      - [CVE-2025-48924](https://github.com/advisories/GHSA-j288-q9x7-2f5v): Apache Commons Lang is vulnerable to Uncontrolled Recursion when processing long inputs
        - **Severity**: **MEDIUM**
        - **Details**: Uncontrolled Recursion vulnerability in Apache Commons Lang.
          
          This issue affects Apache Commons Lang: Starting with commons-lang:commons-lang 2.0 to 2.6, and, from org.apache.commons:commons-lang3 3.0 before 3.18.0.
          
          The methods ClassUtils.getClass(...) can throw StackOverflowError on very long inputs. Because an Error is usually not handled by applications and libraries, a StackOverflowError could cause an application to stop.
          
          Users are recommended to upgrade to version 3.18.0, which fixes the issue.
    </details>
  
    ### ❗ Precheck - Run tests [View Log](logs\4.3.precheck-runTests.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Errors
    Failed to run tests with errors: [ERROR] COMPILATION ERROR :  [ERROR] /c:/Users/EduardoArruda/Documents/Pessoal/src/pucrs/constrsw/constrsw-2025-2/backend/employees/src/main/java/com/constrsw/employees/entity/Task.java:[12,8] error while writing com.constrsw.employees.entity.Task: could not create parent directories [ERROR] Failed to execute goal org.apache.maven.plugins:maven-compiler-plugin:3.13.0:compile (default-compile) on project employees-api: Compilation failure [ERROR] /c:/Users/EduardoArruda/Documents/Pessoal/src/pucrs/constrsw/constrsw-2025-2/backend/employees/src/main/java/com/constrsw/employees/entity/Task.java:[12,8] error while writing com.constrsw.employees.entity.Task: could not create parent directories [ERROR] -\> [Help 1] [ERROR]  [ERROR] To see the full stack trace of the errors, re-run Maven with the -e switch. [ERROR] Re-run Maven using the -X switch to enable full debug logging. [ERROR]  [ERROR] For more information about the errors and possible solutions, please read the following articles: [ERROR] [Help 1] http://cwiki.apache.org/confluence/display/MAVEN/MojoFailureException
      ```
      Error: Failed to run tests with errors:
      [ERROR] COMPILATION ERROR : 
      [ERROR] /c:/Users/EduardoArruda/Documents/Pessoal/src/pucrs/constrsw/constrsw-2025-2/backend/employees/src/main/java/com/constrsw/employees/entity/Task.java:[12,8] error while writing com.constrsw.employees.entity.Task: could not create parent directories
      [ERROR] Failed to execute goal org.apache.maven.plugins:maven-compiler-plugin:3.13.0:compile (default-compile) on project employees-api: Compilation failure
      [ERROR] /c:/Users/EduardoArruda/Documents/Pessoal/src/pucrs/constrsw/constrsw-2025-2/backend/employees/src/main/java/com/constrsw/employees/entity/Task.java:[12,8] error while writing com.constrsw.employees.entity.Task: could not create parent directories
      [ERROR] -\> [Help 1]
      [ERROR] 
      [ERROR] To see the full stack trace of the errors, re-run Maven with the -e switch.
      [ERROR] Re-run Maven using the -X switch to enable full debug logging.
      [ERROR] 
      [ERROR] For more information about the errors and possible solutions, please read the following articles:
      [ERROR] [Help 1] http://cwiki.apache.org/confluence/display/MAVEN/MojoFailureException
          at xne.test (c:\Users\EduardoArruda\.vscode-insiders\extensions\vscjava.vscode-java-upgrade-1.9.1\dist\extension.js:594:2629)
          at Kea (c:\Users\EduardoArruda\.vscode-insiders\extensions\vscjava.vscode-java-upgrade-1.9.1\dist\extension.js:1007:224)
          at Gx.doInvoke (c:\Users\EduardoArruda\.vscode-insiders\extensions\vscjava.vscode-java-upgrade-1.9.1\dist\extension.js:1001:838)
          at Gx.invoke (c:\Users\EduardoArruda\.vscode-insiders\extensions\vscjava.vscode-java-upgrade-1.9.1\dist\extension.js:655:10082)
          at X4e.invoke (c:\Users\EduardoArruda\.vscode-insiders\extensions\vscjava.vscode-java-upgrade-1.9.1\dist\extension.js:1433:172)
          at gQ.$invokeTool (file:///c:/Program%20Files/Microsoft%20VS%20Code%20Insiders/13086c796c/resources/app/out/vs/workbench/api/node/extensionHostProcess.js:194:3199)
      ```
    </details>
  </details>

  ### ✅ Upgrade project to use `Spring Boot 3.4.x`
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  - ###
    ### ✅ Upgrade using Agent [View Log](logs\5.1.upgradeProjectUsingAgent.log)
    22 files changed, 64 insertions(+), 5230 deletions(-)
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Code changes
    - Upgrade Spring Boot to 3.4.0
      - Updated spring-boot-starter-parent version from 3.3.5 to 3.4.0
    </details>
  
    ### ✅ Build Project [View Log](logs\5.2.buildProject.log)
    Build result: 100% Java files compiled
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    `mvn clean test-compile -q -B -fn`
    </details>
  </details>

  ### ✅ Upgrade project to use `Spring Boot 3.5.x`
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  - ###
    ### ✅ Upgrade using Agent [View Log](logs\6.1.upgradeProjectUsingAgent.log)
    1 file changed, 1 insertion(+), 1 deletion(-)
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Code changes
    - Upgrade Spring Boot to 3.5.4
      - Updated spring-boot-starter-parent version from 3.4.0 to 3.5.4
    </details>
  
    ### ❗ Build Project [View Log](logs\6.2.buildProject.log)
    Build result: 94% Java files compiled
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    `mvn clean test-compile -q -B -fn`
    
    #### Errors
    - === Config File error     The below errors can be due to missing dependencies. You may have to refer     to the config files provided earlier to solve it.     'errorMessage': Failed to execute goal org.apache.maven.plugins:maven-clean-plugin:3.4.1:clean (default-clean) on project employees-api: Failed to clean project: Failed to delete C:\Users\EduardoArruda\Documents\Pessoal\src\pucrs\constrsw\constrsw-2025-2\backend\employees\target\classes\com\constrsw\employees\config 
      ```
      Failed to execute goal org.apache.maven.plugins:maven-clean-plugin:3.4.1:clean (default-clean) on project employees-api: Failed to clean project: Failed to delete C:\Users\EduardoArruda\Documents\Pessoal\src\pucrs\constrsw\constrsw-2025-2\backend\employees\target\classes\com\constrsw\employees\config
      ```
    </details>
  
    ### ✅ Fix Build Errors [View Log](logs\6.3.fixBuildErrors.log)
    59 files changed, 0 insertions(+), 5342 deletions(-)
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Code changes
    - Clean target directory manually to resolve file lock issues
      - Retry build after removing target directory
    </details>
  
    ### ✅ Build Project [View Log](logs\6.4.buildProject.log)
    Build result: 100% Java files compiled
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    `mvn clean test-compile -q -B -fn`
    </details>
  </details>

  ### ⏳ Validate & Fix ...Running